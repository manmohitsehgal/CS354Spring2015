/*------------------------------------------------------------------------
 *  New Queue: Follows the policy for Extra Credit
 *------------------------------------------------------------------------
 */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  enqueueMessageToSend  -  Insert a message at the tail of a queue
 *------------------------------------------------------------------------
 */

umsg32 enqueueMessageToSend (umsg32 sendMessage, pid32 pid) {
	
	if (isbadpid(pid)) {
		return SYSERR;
	}

	int totalMessages;
	struct	procent *prptr; /* process table pointer */
	prptr = &proctab[pid];
	
	totalMessages = prptr->totalNumberOfMessagesToSend;
	prptr->qMessage[totalMessages] = sendMessage;
	//kprintf("\n first messages %d\n\r", prptr->qMessage[i]);
	prptr->totalNumberOfMessagesToSend = totalMessages + 1; // increment the message count here
	//kprintf("\n total number %d\n\r", prptr->totalNumberOfMessagesToSend);
	return sendMessage;
}


/*------------------------------------------------------------------------
 *  deaqueueMessageToSend  -  Remove and return the first messge on a list
 *------------------------------------------------------------------------
 */

umsg32 deaqueueMessageToSend (pid32 pid) {

	if (isbadpid(pid)) {
		return SYSERR;
	}
	
	struct	procent *prptr; /*process table pointer*/
	prptr = &proctab[pid];

	int i = 0;
	umsg32 messageToSend;

	messageToSend = prptr->qMessage[0]; // starts from the first message
	
	while( i < prptr->totalNumberOfMessagesToSend-1){
		//kprintf("loop started \r\n");
		//kprintf("reached here \r\n");
		prptr->qMessage[i] = prptr->qMessage[i+1];
		//kprintf("\n messages %d\n\r", prptr->qMessage[i]);
		i++;	
		//kprintf("finished %d  \r\n", i);

	}

	
	prptr->totalNumberOfMessagesToSend = prptr->totalNumberOfMessagesToSend - 1; // decerement the message count here

	return messageToSend;
}
